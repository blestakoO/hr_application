-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 09, 2023 at 08:33 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hr`
--

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(20) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `address` varchar(50) NOT NULL,
  `salary` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `name`, `email`, `phone`, `address`, `salary`) VALUES
(1, 'Gennifer', 'gpegden0@blogtalkrad', '1084724784', '997 New Castle Junction', '€2925,40'),
(2, 'Lydie', 'lrogliero1@redcross.', '3509055457', '83 Mcguire Crossing', '€1034,33'),
(3, 'Alair', 'agoodrich2@japanpost', '2691777299', '192 Oak Valley Point', '€1519,98'),
(4, 'Emily', 'ekennady3@is.gd', '7719510325', '3445 Monument Trail', '€1450,14'),
(5, 'Rina', 'rquaintance4@google.', '3733843318', '27003 Erie Crossing', '€3442,15'),
(6, 'Lenee', 'lschustl5@shop-pro.j', '3309793970', '0 Artisan Court', '€2958,43'),
(7, 'Webster', 'wtungay6@oaic.gov.au', '3145212478', '376 Union Lane', '€1568,87'),
(8, 'Gaylor', 'gcroll7@constantcont', '9331846389', '0671 Independence Alley', '€3829,48'),
(9, 'Ruthann', 'rdow8@hud.gov', '2019483706', '24 Karstens Crossing', '€3443,92'),
(10, 'Dara', 'delmer9@google.de', '6205190135', '0494 Kingsford Drive', '€2943,39');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
