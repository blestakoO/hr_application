#import mysql connector
import mysql.connector
import os

# making MySQL connection object
hr = mysql.connector.connect(
  host="localhost",
  user="root",
  password="",
  database="blest_veshi")
mycursor = hr.cursor()


#function gia na prosthesoume ergati --ERWTHMA 1o
def add_employee():
    print("{:>45}".format("Adding Employee"))
    name = input("Enter employee name: ")
    email = input("Enter employee email: ")
    phone = input("Enter employee phone: ")
    address = input("Enter employee address: ")
    salary = input("Enter employee salary: ")
    value = (name, email, phone, address, salary)

    sql = "INSERT INTO employees (name,email,phone,address,salary) VALUES (%s, %s, %s, %s, %s)"
    mycursor.execute(sql, value)
    hr.commit()
    print("Successfully added employee")
    press = input("press any key to go back to menu...")
    menu()


def clear():
    os.system('cls')

#function gia na emfanisoume ta stoixeia ergati meso ID --ERWTHMA 2o
def employee_info():

    id = input("Enter Employee ID: ")
    sql='SELECT name,email,phone,address,salary FROM employees where id=%s'
    value = (id,)
    mycursor.execute(sql, value)

    info = mycursor.fetchone()

    print(info)

    press = input("press any key to go back to menu...")
    clear()
    menu()


#function gia na allaksoume ta stoixeia tou ergati meso ID --ERWTHMA 3o
def update_employee():
    id= input("Enter Employee ID: ")
    sql='SELECT name,email,phone,address,salary FROM employees where id=%s'
    value= (id,)
    mycursor.execute(sql, value)
    info= mycursor.fetchone()
    print(info)

    name = input("Enter employee name: ")
    email = input("Enter employee email: ")
    phone = input("Enter employee phone: ")
    address = input("Enter employee address: ")
    salary = input("Enter employee salary: ")
    value = (name, email, phone, address, salary, id)

    sql = "UPDATE employees set name=%s,email=%s,phone=%s,address=%s,salary=%s WHERE id=%s"
    mycursor.execute(sql, value)
    hr.commit()

    print("Successfully updated employee")

    press = input("press any key to go back to menu...")
    clear()
    menu()




#function gia na anevasoume ton mistho tou ipalilou --- 4o ERWTHMA
def update_salary():
    id= input("Enter Employee ID: ")
    sql='SELECT name,salary FROM employees where id=%s'
    value= (id,)
    mycursor.execute(sql, value)
    info= mycursor.fetchone()
    print(info)

    salary = input("Enter the new salary of the employee: ")
    value = (salary, id)

    sql='UPDATE employees set salary = %s WHERE id=%s'
    val= (salary, id)

    mycursor.execute(sql, value)
    hr.commit()

    print("Successfully updated the salary of the employee")

    press = input("press any key to go back to menu...")
    clear()
    menu()



#function gia diagrafi tou ipalilou apo to database 5o ERWTHMA
def delete_employee():
    id= input("Enter Employee ID: ")
    sql='SELECT name,email,phone,address,salary FROM employees where id=%s'
    value= (id,)
    mycursor.execute(sql, value)
    info= mycursor.fetchone()
    print(info)

    answer = int(input("Are You sure you want to delete this employee--> 1.YES *** 2.NO : "))
    if answer == 1:
      sql='DELETE FROM employees WHERE id=%s'
      value=(id,)
      mycursor.execute(sql, value)
      hr.commit()
      print('Employee deleted')
      press = input("press any key to go back to menu...")
      menu()
    else:
      print('Employee will not be deleted')
      press = input("press any key to go back to menu...")
      clear()
      menu()


def employee_search():

    id = input("Enter Employee ID: ")
    sql='SELECT name FROM employees where id=%s'
    value = (id,)
    mycursor.execute(sql, value)

    info = mycursor.fetchone()

    print(info)

    press = input("press any key to go back to menu...")
    clear()
    menu()


#menu epilogon gia ton xristi
def menu():
    print("{:>45}".format("HR-G6 Employee Managment system"))
    print("1. Add Employee")
    print("2. Display Employee Data")
    print("3. Update Employee Data")
    print("4. Give Employee A Payraise")
    print("5. Delete Employee Record")
    print("6. Search Employee Record")
    print("7. Exit")
    print("{:>45}".format("Choice Options: 1 * 2 * 3 * 4 * 5 * 6 * 7 "))


#metafora sto analogo function analoga me tin apantisi tou xristi
    chose = int(input("Chose number: "))
    if chose ==1:
        add_employee()
    elif chose ==2:
        employee_info()
    elif chose ==3:
        update_employee()
    elif chose ==4:
        update_salary()
    elif chose ==5:
        delete_employee()
    elif chose ==6:
        employee_search()
    elif chose ==7:
        print('Exiting...')
        exit()
    else:
        print("invalid choice")
        press = input("Press any key to continue..")


menu()







